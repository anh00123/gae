package com.stir.cscu9t4practical1;


public class CycleEntry extends Entry{
    protected String terrain, speed, activity;

    public CycleEntry(String n, int d, int m, int y, int h, int min, int s, float dist, String terrain, String speed, String activity) {
        super(n, d, m, y, h, min, s, dist);
        this.terrain = terrain;
        this.speed = speed;
        this.activity = activity;

    }


    public String getTerrain(){
        return terrain;
    }

    public String getTempo()
    {
        return speed;
    }

    public String getActivity()
    {
        return activity;
    }

    @Override
    public String getEntry () {
        String result = getName()+" " + getActivity() + " " + getDistance() + " km in "
                +getHour()+":"+getMin()+":"+ getSec() + " on "
                +getDay()+"/"+getMonth()+"/"+getYear()+ " on " + getTerrain()+ " at " + getTempo()+ " tempo" + "\n";
        return result;
    }

}
